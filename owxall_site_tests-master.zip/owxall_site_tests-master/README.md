# owxall_site_tests
Learn selenium with Oxwall site
